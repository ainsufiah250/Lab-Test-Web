<%-- 
    Document   : schedule
    Created on : 16 Jun 2026, 4:01:34 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Schedule of the Session</h1>
        <table border="1" cellpadding="8">
            <thead>
                <tr style="background-color: lightblue;">
                    <th>Student ID</th><!-- comment -->
                    <th>Student Name</th><!-- comment -->
                    <th>Branch Location</th><!-- comment -->
                    <th>Type of Lesson</th><!-- comment -->
                    <th>Status</th><!-- comment -->
                </tr>
            </thead>
            <tbody>
            <c:forEach items="${listData}" var="student" varStatus="status">
                <tr> 
                    <td>${status.count}</td>
                    <td>${student.name}</td>
                    <td>${student.id}</td> 
                    <td>${branch.location}</td>
                    <td>${lesson.type}</td>    
            </c:forEach>
            </tbody>
        </table>
    </body>
</html>
