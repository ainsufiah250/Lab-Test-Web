<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 3:37:21 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Booking Session</h1>
        
        <form id="student_id" action="BookSessionServlet" method="POST" >
            <fieldset> 
                <legend>Student Booking</legend>
                
                <label for="student_id">ID. No</label>
                <input type="text" id="idno" name="student_idno" size="15"
                       placeholder="E.g. 971203040234"><br/><!-- comment -->
                
                <label for="student_name">Student Name</label><!-- comment -->
                <input type="text" id="name" name="student_name" size="50"
                       placeholder="Key-in your name"><br/><!-- comment -->
                
                <label for="branch_location">Branch Location</label>
                <select branch_location="location" size="100">
                    <option value="0">Kuala Lumpur</option><!-- comment -->
                    <option value="1">Kuala Terengganu</option>
                    <option value="2">Penang</option>
                    <option value="3">Johor Bahru</option>
                    <option value="4">Kuantan</option>
                    <option value="5">Kedah</option> 
                </select>
                
                <label for="lesson_type">Type of Lesson</option><!-- comment -->
                <select lesson_type="Type of Lesson" size="50">
                    <option value="0">Manual Car</option>
                    <option value="1">Automatic Car</option> 
                    <option value="2">Motorcycle</option>
                    <option value="3">Lorry</option>
                </select>
        </form>
            
        
    </body>
</html>
