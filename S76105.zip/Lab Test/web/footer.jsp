<%-- 
    Document   : footer
    Created on : 16 Jun 2026, 4:28:57 PM
    Author     : MP2-4
--%>



<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<!DOCTYPE html>
<html>
<body>
     <jsp:useBean id="now" class="java.util.Date" />
     
          <strong>
              <fmt:formatDate value="${now}" type="date" />
          </strong>
     
           <strong>
               <fmt:formatDate value="${now}" type="time" />
           </strong>
  
           <strong>
               <fmt:formatDate value="${now}" type="both" />
           </strong>

          <strong>
               <fmt:formatDate value="${now}" pattern="dd MMMM yyyy, hh:mm:ss a" />
          </strong>

</body>
</html>

