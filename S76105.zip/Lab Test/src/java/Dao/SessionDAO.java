/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;
import Model.SessionBean;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.catalina.User;


/**
 *
 * @author MP2-4
 */
public class SessionDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/drivesmart_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";
    
    protected Connection getConnection() {
        Connection connection = null;
        try  {
             Class.forName("com.mysql.cj.jdbc.Driver");
             connection = DriverManager.getConnection(jdbcURL,jdbcUsername, jdbcPassword);
        } catch (SQLException | ClassNotFoundException e) {
             e.printStackTrace();
        }
        return connection;
}
    
public void insertUser(User session_id) throws SQLException {
    String sql = "INSERT INTO training_sessions (session_id, student_name, branch_location, lesson_type, status) VALUES (?, ?, ?, ?, ?)";
    
    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
         pstmt.setString(1, user.getSession_id());
         pstmt.setString(2, user.getStudent_name());
         pstmt.setString(3, user.getBranch_location());
         pstmt.setString(4, user.getBranch_location());
         pstmt.setString(5, user.getLesson_type());
         pstmt.setString(6, user.getStatus());
         pstmt.executeUpdate();
         
    } catch (SQLException e) {
        e.printStackTrace();
    }
         
}  
}
