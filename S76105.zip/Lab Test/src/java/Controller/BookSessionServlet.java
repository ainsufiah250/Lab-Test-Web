/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author MP2-4
 */
public class BookSessionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String student_name = request.getParameter("student name");
        String branch_location = request.getParameter("branch location");
        String lesson_type = request.getParameter("Type of lesson");
        String status = request.getParameter ("Status");
        
        try {
           Class.forName("com.mysql.cj.jdbc.Driver");
           Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/driversmart_db", "root", "");
           
           String sql = "INSERT INTO training_session (student_name, branch_location, lesson_types, status)VALUES (?, ?, ?, ?, ?)";
           PreparedStatement pstmt = conn.prepareStatement(sql);
           pstmt.setString(1, student_name);
           pstmt.setString(2,branch_location);
           pstmt.setString(3, lesson_type);
           pstmt.setString(4,status);
           pstmt.executeUpdate();
           
           pstmt.close();
           conn.close();
           
        response.sendRedirect("ScheduleServlet");
        
    }   catch (ClassNotFoundException ex) {
            Logger.getLogger(BookSessionServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BookSessionServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}